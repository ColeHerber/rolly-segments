#ifndef WIFICONNECTION_H
#define WIFICONNECTION_H

void setupWiFi();

#endif